//Amazon

//find SSN numbers in a file that contains other information


//SSN: ^\d{3}-\d{2}-\d{4}$

//phone numbner: ^\d{3}-\d{3}-\d{4}$

//domain name: [\w\-]+(\.[\w\-]+)+

//html tag: <.+?>

//email: ^[\w!#$%&'*+/=?^_`{}~-]+@[\w\-]+(\.[\w\-]+)+$